-----------stored procedure for showing bloodbank based on request----------------

GO
CREATE PROC request_view 
(
	@id INT,
	@group VARCHAR(5),
	@region VARCHAR(20),
	@numofbottles INT
)
AS
BEGIN
	SELECT bb.BloodBankId,bb.BloodBankname,bb.bbregion,bb.bbaddress,bb.bbcity,bb.bbMobNo FROM 
	BBMS.BloodInventory bi,BBMS.Hospital h,BBMS.BloodBank bb 
	WHERE 
	h.hospitalid=@id 
	AND 
	bi.BloodGroup=@group 
	AND 
	bb.bbregion=@region 
	AND 
	bi.NoOfBottles>=@numofbottles 
	AND 
	bb.BloodBankId=bi.BloodBankId 
	GROUP BY
	bb.BloodBankId,bb.BloodBankname,bb.bbregion,bb.bbaddress,bb.bbcity,bb.bbMobNo
END


DROP PROC request_view


-----------stored procedure for showing bloodbank based on request----------------

GO
CREATE PROC request_view1
(
	@id INT,
	@group VARCHAR(5),
	@city VARCHAR(20),
	@numofbottles INT
)
AS
BEGIN
	SELECT bb.BloodBankId,bb.BloodBankname,bb.bbregion,bb.bbaddress,bb.bbcity,bb.bbMobNo FROM 
	BBMS.BloodInventory bi,BBMS.Hospital h,BBMS.BloodBank bb 
	WHERE 
	h.hospitalid=@id 
	AND 
	bi.BloodGroup=@group 
	AND 
	bb.bbcity=@city 
	AND 
	bi.NoOfBottles>=@numofbottles 
	AND 
	bb.BloodBankId=bi.BloodBankId
	GROUP BY
	bb.BloodBankId,bb.BloodBankname,bb.bbregion,bb.bbaddress,bb.bbcity,bb.bbMobNo 
END


DROP PROC request_view1




------stored procedure for showing donor details based on requests-------------
GO
CREATE PROC request_donorview
(
	@id INT,
	@group VARCHAR(5),
	@city VARCHAR(20)
)
AS
BEGIN
	SELECT bd.BloodDonorId,bd.firstname,bd.lastname,bd.donoraddress,bd.donorcity,bd.donormobnum,bd.units,
	bd.weights,bd.donationDATE,bd.hbCount 
	FROM BBMS.BloodDonor bd,BBMS.Hospital h 
	WHERE 
	h.hospitalid=@id 
	AND
	bd.donorbloodgroup=@group 
	AND 
	(bd.donorcity=@city AND bd.donationDATE<=DATEADD(m,-3,CONVERT(DATE,CONVERT(VARCHAR(6),GETDATE())+'01')))
	GROUP BY
	bd.BloodDonorId,bd.firstname,bd.lastname,bd.donoraddress,bd.donorcity,bd.donormobnum,bd.units,
	bd.weights,bd.donationDATE,bd.hbCount
END


DROP PROC request_donorview