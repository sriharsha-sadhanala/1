﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.DAL;

namespace BBMS.BL
{
    public class AdminReportBL
    {
        AdminReportDL adl = new AdminReportDL();
        public List<Hospitals> GetHospitalDetails()
        {
            try
            {
                return adl.GetHospitalDetails();
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }
        public List<Bloodbank> GetBankDetails()
        {
            try
            {
                return adl.GetBankDetails();
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Donor> GetDonorDetails()
        {
            try
            {
                return adl.GetDonorDetails();
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<BloodCamp> GetCampDetails()
        {
            try
            {
                return adl.GetCampDetails();
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<BloodInventory> GetInventoryDetails()
        {
            try
            {
                return adl.GetInventoryDetails();
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
