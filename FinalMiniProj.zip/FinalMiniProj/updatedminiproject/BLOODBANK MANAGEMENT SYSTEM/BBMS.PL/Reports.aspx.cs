﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BBMS.BL;
using BBMS.Entity;
using BBMS.Exceptions;

namespace BBMS.PL
{
    public partial class Reports : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AdminReportBL arl=new AdminReportBL ();
            if(DropDownList1.SelectedItem.Value=="Blood Bank")
            {
                lblheading.Text = "Blood Bank Details";
                GridView1.DataSource = arl.GetBankDetails();
                GridView1.DataBind();
            }
            else if(DropDownList1.SelectedItem.Value=="Hospital")
            {
                lblheading.Text = "Hospital Details";
                GridView1.DataSource = arl.GetHospitalDetails();
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedItem.Value == "Donor")
            {
                lblheading.Text = "Donor Details";
                GridView1.DataSource = arl.GetDonorDetails();
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedItem.Value == "Camp")
            {
                lblheading.Text = "Camp Details";
                GridView1.DataSource = arl.GetCampDetails();
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedItem.Value == "Inventory")
            {
                lblheading.Text = "Inventory Details";
                GridView1.DataSource = arl.GetInventoryDetails();
                GridView1.DataBind();
            }
            else
            {
                lblheading.Text = "Select any option";
            }
        }
    }
}