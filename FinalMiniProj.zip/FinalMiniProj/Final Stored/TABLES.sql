CREATE SCHEMA BBMS

1)-----TABLE of blood inventory

CREATE TABLE BBMS.BloodInventory
(
	BloodInventoryId INT PRIMARY KEY,
	BloodGroup VARCHAR(5),
	NoOfBottles INT,
	BloodBankId INT FOREIGN KEY REFERENCES BBMS.BloodBank(BloodBankId),
	expiryDATE DATE
)

INSERT INTO BBMS.BloodInventory
VALUES(1,'O+ve',5,100100,'07-08-2018')

INSERT INTO BBMS.BloodInventory 
VALUES(2,'AB+ve',5,100101,'07-09-2018')

DROP TABLE BBMS.BloodInventory


2)------TABLE of Bloodbank


CREATE TABLE BBMS.BloodBank 
(
	BloodBankId INT PRIMARY KEY,
	BloodBankname VARCHAR(20),
	bbaddress VARCHAR(50),
	bbregion VARCHAR(20),
	bbcity VARCHAR(20),
	bbMobNo VARCHAR(15),
	bbuser VARCHAR(20),
	bbpwd VARCHAR(20)
)

INSERT INTO BBMS.BloodBank 
VALUES(100100,'ABC','ABC Apartments','Airoli','Mumbai',7893360561,'abcuser','abcuser')

INSERT INTO BBMS.BloodBank
VALUES(100101,'DEF','DEF Apartments','Mulund','Mumbai',7893360562,'defuser','defuser')

SELECT * FROM BBMS.BloodBank
SELECT * FROM BBMS.BloodInventory
SELECT * FROM BBMS.StockTransfer

DROP TABLE BBMS.BloodBank

3)----TABLE of blood donation camp

DROP TABLE BBMS.BloodDonationCamp

CREATE TABLE BBMS.BloodDonationCamp
(
	Donationcampid INT PRIMARY KEY,
	campName VARCHAR(50),
	campcity VARCHAR(20),
	BloodbankId INT FOREIGN KEY REFERENCES BBMS.BloodBank(BloodBankId),
	campstartDATE DATE,campENDDATE DATE
);

INSERT INTO BBMS.BloodDonationCamp 
VALUES(1001,'harsha','chirala','hyd',100101,'07-08-2015','12-08-2016')

SELECT * FROM BBMS.BloodDonationCamp

4)----TABLE of Hospital

CREATE TABLE BBMS.Hospital
(
	hospitalid INT PRIMARY KEY,
	hospitalname VARCHAR(20),
	hospaddress VARCHAR(50),
	city VARCHAR(15),
	region VARCHAR(20),
	contact VARCHAR(15)
)

INSERT INTO BBMS.Hospital 
VALUES(1001,'Appolo','Hyderabad','ANDhra pradesh','Kadap','1234567890')

INSERT INTO BBMS.Hospital
VALUES(1002,'KIMS','Hyderabad','ANDhra pradesh','Tirupati','9876543210')

SELECT * FROM  BBMS.Hospital

DROP TABLE  BBMS.Hospital

5)------TABLE of Blood donor

CREATE TABLE BBMS.BloodDonor
(
	BloodDonorId INT PRIMARY KEY,
	firstname VARCHAR(20),
	lastname VARCHAR(20),
	donoraddress VARCHAR(50),
	donorcity VARCHAR(20),
	donormobnum VARCHAR(15),
	donorbloodgroup VARCHAR(5),
	units INT,
	age INT,
	weights INT,
	donationId INT,
	donationDATE DATE,
	BloodbankId INT FOREIGN KEY REFERENCES BBMS.BloodBank(BloodBankId),
	hbcount INT
)

INSERT INTO BBMS.BloodDonor 
VALUES(10001,'Latha','Reddy','Kadapa','SPuram',7893360561,'O+ve',2,22,60,1,'12-09-2017',4,100100,13)

INSERT INTO BBMS.BloodDonor 
VALUES(10002,'Madhu','Reddy','chirala','RangASthalam',7893360562,'B+ve',5,23,70,2,'12-07-2017',5,100101,14)

DROP TABLE BBMS.BloodDonor

--6)----TABLE of BloodDonorDonation

--CREATE TABLE BBMS.BloodDonorDonation(bloodDonationId INT ,bloodDonorId INT,bloodDonationDATE DATE,
--numberOfBottle INT,bloodweight float,
--hbCount float,units INT,FOREIGN KEY(BloodDonorId) REFERENCES BBMS.BloodDonor(BloodDonorId))

--DROP TABLE BBMS.BloodDonorDonation


6)----TABLE for admin login


CREATE TABLE BBMS.AdminLogin
(
	Username VARCHAR(10) PRIMARY KEY,
	PASswrd VARCHAR(10)
)

INSERT INTO  BBMS.AdminLogin 
VALUES('admin','admin');

SELECT * FROM BBMS.AdminLogin

DROP TABLE BBMS.AdminLogin


7)-------TABLE of stock transfer---

CREATE TABLE BBMS.StockTransfer
(
	BloodbankId INT ,
	HospitalName VARCHAR(20),
	BloodGroup VARCHAR(5),
	Quantity INT,
	DATETransfer DATE,
	FOREIGN KEY(BloodBankId) REFERENCES BBMS.BloodBank(BloodBankId)
)


DROP TABLE BBMS.StockTransfer


-----TABLE of  hospital request



CREATE TABLE BBMS.HospitalRequest
(
	hospitalid INT,
	hospitalname VARCHAR(20),
	hospaddress VARCHAR(30),
	hospcity VARCHAR(10),
	hospregion VARCHAR(10),
	hospDATE DATE,
	hosbloodgroup VARCHAR(5),
	noofpackets INT
)

