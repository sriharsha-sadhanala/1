﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

using BBMS.Exceptions;
using BBMS.Entity;

namespace BBMS.DAL
{
    public class LoginDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;

        public bool AdminCheck(AdminLogin adm)
        {
            bool valid = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BBMS_AdminLogin";
                cmd.Parameters.AddWithValue("@username", adm.Username);
                cmd.Parameters.AddWithValue("@password", adm.Password);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    valid=true;
                }
                else
                {
                    con.Close();
                    valid=false;
                }
            }
            catch(BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }

            return valid;
        }

        public int ValidateBankLogin(Bloodbank bb)
        {
            int id = 0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_bblogin";
                cmd.Parameters.AddWithValue("@user", bb.BloodBankUserId);
                cmd.Parameters.AddWithValue("@password",bb.BloodBankPwd);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    id = dr.GetInt32(0);
                    con.Close();
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return id;
        }
    }
}
