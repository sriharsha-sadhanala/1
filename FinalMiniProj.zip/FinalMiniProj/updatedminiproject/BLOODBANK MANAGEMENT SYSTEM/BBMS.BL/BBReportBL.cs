﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.DAL;

namespace BBMS.BL
{
    public class BBReportBL
    {
        BBReportDL bdl = new BBReportDL();
        public List<Donor> GetDonorDetails(int id)
        {
            try
            {
                return bdl.GetDonorDetails(id);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<BloodCamp> GetCampDetails(int id)
        {
            try
            {
                return bdl.GetCampDetails(id);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<BloodInventory> GetInventoryDetails(int id)
        {
            try
            {
                return bdl.GetInventoryDetails(id);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
