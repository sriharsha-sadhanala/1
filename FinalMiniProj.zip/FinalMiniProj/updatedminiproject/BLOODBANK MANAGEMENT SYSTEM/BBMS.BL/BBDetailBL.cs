﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.DAL;

namespace BBMS.BL
{
    public class BBDetailBL
    {
        BBDetailDL bdl = new BBDetailDL();
        public bool UpdateBankDetails(Bloodbank b)
        {
            try
            {
                bool valid = true;
                StringBuilder sb = new StringBuilder();
         
                var expr = new Regex("^[0-9]{5,10}$");
                if (expr.IsMatch(b.BloodBankMobNo) != true)
                {
                    valid = false;
                    sb.Append(" Contact no can only be digits ");
                }
                if (valid == false)
                {
                    throw new BloodExceptions(sb.ToString());
                }
            }
            catch (BloodExceptions be)
            {
                throw be;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return bdl.UpdateBankDetail(b);
        }
        public Bloodbank GetBankDetailsById(Bloodbank bb)
        {
            try
            {
                return bdl.GetBankDetailsById(bb);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
