---stored PROCedure admin login

GO
CREATE PROC BBMS_AdminLogin
(
	@username VARCHAR(10),
	@password VARCHAR(10)
)
AS 
BEGIN
	SELECT * FROM 
	BBMS.AdminLogin 
	WHERE 
	Username=@username 
		AND Passwrd=@password
END	
GO

DROP PROC BBMS_AdminLogin
EXEC BBMS_AdminLogin 'admin','Admin'


---------------Stored PROCedure for Adding Hospital details by admin
--GO
--CREATE PROC hosp_add @hid INT,@hname VARCHAR(20),@haddress VARCHAR(50),@hcity VARCHAR(15) AS 
--INSERT INTO BBMS.Hospital(hospitalid,hospitalname,hospaddress,city) VALUES(@hid,@hname,@haddress,@hcity)
--GO


---Stored PROCedure for adding hospital id AND hospital name by admin


GO 
CREATE PROC hospadm_add 
(
	@hid INT,
	@hname VARCHAR(20)
)
AS
BEGIN
	INSERT INTO BBMS.Hospital(hospitalid,hospitalname,hospaddress,city,contact,region) 
	VALUES(@hid,@hname,'','','','')
END
GO

DROP PROC hospadm_add


------------------Stored PROCedure for deleting Hosptital details by admin
GO
CREATE PROC hosp_del
(
	@hid INT
)
AS
BEGIN
	DELETE FROM BBMS.Hospital 
	WHERE hospitalid=@hid
END
GO

---stored PROCedure for updating hospital details

GO
CREATE PROC hosp_upd
(
	@hid INT,
	@hname VARCHAR(20),
	@haddress VARCHAR(50),
	@hcity VARCHAR(15),
	@region VARCHAR(20),
	@contact VARCHAR(20)
)
AS
BEGIN
	UPDATE  BBMS.Hospital
	SET
		hospitalname=@hname,
		hospaddress=@haddress,
		city=@hcity,
		region=@region,
		contact=@contact
	WHERE 
	hospitalid=@hid
END
GO

SELECT * FROM BBMS.Hospital

EXEC hosp_upd 1001,'AIIMS','312 MG','Delhi','hah','7678'

DROP PROC hosp_upd


---stored PROCedure for showing details of the hospitals by id

GO
CREATE PROC hosp_showbyid
(
	@hid INT
)
AS
BEGIN
	SELECT * FROM
	BBMS.Hospital 
	WHERE
	hospitalid=@hid
END
GO







-----stored PROCedurs for admin operation related to bloodbank------------------------------------------------------------------
---stored PROCedure for Bloodbank---
 
 ------stored PROCedure for adding hospital name AND id


 GO
 CREATE PROC bank_add
(
	@bid INT,
	@bname VARCHAR(20)
)
AS
BEGIN
	INSERT INTO BBMS.BloodBank(BloodBankId,BloodBankname,bbaddress,bbregion,bbcity,bbMobNo,bbuser,bbpwd)
	VALUES(@bid,@bname,'','','','','','')
END 
GO

 DROP PROC BANK_ADD

 SELECT * FROM BBMS.BloodBank

 EXEC BANK_ADD 100102,'GHI'

---stored PROCedure for updating----

GO
CREATE PROC bank_upd
(
	@bid INT,
	@bname VARCHAR(20),
	@baddress VARCHAR(50),
	@bregion VARCHAR(20),
	@bcity VARCHAR(15),
	@bmobnum VARCHAR(20)
)
AS
BEGIN
	UPDATE  BBMS.BloodBank 
	SET
	BloodBankname=@bname,
	bbaddress=@baddress,
	bbregion=@bregion,
	bbcity=@bcity,
	bbMobNo=@bmobnum
	WHERE
	BloodBankId=@bid
END
GO

SELECT * FROM BBMS.BloodBank

DROP PROC bank_upd

EXEC bank_upd 100100,'ABC','ABC Apartments','Thane','Mumbai',7893365789


--stored PROCedure for deleting---
GO
CREATE PROC bank_del 
(
	@bid INT
)
AS
BEGIN
	DELETE FROM BBMS.BloodBank
	WHERE 
	BloodBankId=@bid
END
GO

---stored PROCedure for showing bloodbank details by id---

GO
CREATE PROC bank_showbyid
(
	@bid INT
)
AS
BEGIN
	SELECT 
		BloodBankId,
		BloodBankname,
		bbaddress,
		bbregion,
		bbMobNo,
		bbcity 
	FROM 
		BBMS.BloodBank 
	WHERE
		BloodBankId=@bid
END
GO

DROP PROC bank_showbyid

EXEC bank_showbyid 456456

-----stored PROCedures for showing all details---------------------------------------------------------------
--stored PROCedure for showing all details---


GO
CREATE PROC hosp_showall
AS
BEGIN
	SELECT * FROM BBMS.Hospital
END
GO

DROP PROC hosp_showall

EXEC hosp_showall

---stored PROCedure for showing bloodbank details


GO
CREATE PROC bank_showall
AS
BEGIN
	SELECT * FROM BBMS.BloodBank
END
GO

EXEC bank_showall

DROP PROC bank_showall


--stored PROCedure for showing inventory details
GO
CREATE PROC inventory_show
AS
BEGIN
	SELECT * FROM BBMS.BloodInventory
END
GO

DROP PROC inventory_show

EXEC inventory_show


--stored PROCedure for showing donor details

GO
CREATE PROC donor_show
AS
BEGIN
	SELECT * FROM BBMS.BloodDonor
END
GO

DROP PROC donor_show

---stored PROCedure for showing all campdetails

GO
CREATE PROC camp_show
AS
BEGIN
	SELECT * FROM BBMS.BloodDonationCamp
END
GO