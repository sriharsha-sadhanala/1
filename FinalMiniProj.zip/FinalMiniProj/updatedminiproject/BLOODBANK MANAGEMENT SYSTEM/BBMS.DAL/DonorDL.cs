﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.Exceptions;
using BBMS.Entity;

namespace BBMS.DAL
{
    public class DonorDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public bool AddDonor(Donor donor)
        {
            bool donoradded = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_adddonor";
                cmd.Parameters.AddWithValue("@bloodbankid", donor.BloodBankID);
                cmd.Parameters.AddWithValue("@id", donor.DonorID);
                cmd.Parameters.AddWithValue("@fname", donor.firstname);
                cmd.Parameters.AddWithValue("@lname", donor.lastname);
                cmd.Parameters.AddWithValue("@add", donor.Address);
                cmd.Parameters.AddWithValue("@city", donor.City);
                cmd.Parameters.AddWithValue("@mobileno", donor.Mobile);
                cmd.Parameters.AddWithValue("@age", donor.Age);
                cmd.Parameters.AddWithValue("@weight", donor.Weight);
                cmd.Parameters.AddWithValue("@bloodgroup", donor.BloodGroup);
                cmd.Parameters.AddWithValue("@units", donor.NoOfBottles);
                cmd.Parameters.AddWithValue("@donationdate", donor.DonationDate);
                cmd.Parameters.AddWithValue("@hbcount", donor.HBcount);
                cmd.Parameters.AddWithValue("@donationid", donor.DonationID);
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    donoradded = true;
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return donoradded;
        }

        public bool DelDonor(Donor donor)
        {
            bool donordeleted = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_donordelete";
                cmd.Parameters.AddWithValue("@bid", donor.BloodBankID);
                cmd.Parameters.AddWithValue("@id", donor.DonorID);
               
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    donordeleted = true;
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return donordeleted;
        }
        public bool UpdateDonor(Donor d)
        {
            bool updated = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_update";
                //cmd.Parameters.AddWithValue("@bid",d.BloodBankID);
                cmd.Parameters.AddWithValue("@id", d.DonorID);
                cmd.Parameters.AddWithValue("@fname", d.firstname);
                cmd.Parameters.AddWithValue("@lname", d.lastname);
                cmd.Parameters.AddWithValue("@add", d.Address);
                cmd.Parameters.AddWithValue("@city", d.City);
                cmd.Parameters.AddWithValue("@mobileno", d.Mobile);
                cmd.Parameters.AddWithValue("@age", d.Age);
                cmd.Parameters.AddWithValue("@weight", d.Weight);
                cmd.Parameters.AddWithValue("@bloodgroup", d.BloodGroup);
                cmd.Parameters.AddWithValue("@units", d.NoOfBottles);
                cmd.Parameters.AddWithValue("@donationdate", d.DonationDate);
                cmd.Parameters.AddWithValue("@hbcount", d.HBcount);
                cmd.Parameters.AddWithValue("@donationid", d.DonationID);
                cmd.Parameters.AddWithValue("@bloodbankid", d.BloodBankID);
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    updated = true;
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return updated;
        }
        public Donor SearchDonorById(Donor d)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_DonorSearchById";
                cmd.Parameters.AddWithValue("@bid", d.BloodBankID);
                cmd.Parameters.AddWithValue("@id", d.DonorID);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    d = new Donor();
                    d.DonorID = dr.GetInt32(0);
                    d.firstname = dr.GetString(1);
                    d.lastname = dr.GetString(2);
                    d.Address = dr.GetString(3);
                    d.City = dr.GetString(4);
                    d.Mobile = dr.GetString(5);
                    d.BloodGroup = dr.GetString(6);
                    d.NoOfBottles = dr.GetInt32(7);
                    d.Age = dr.GetInt32(8);
                    d.Weight = dr.GetInt32(9);
                    d.DonationID = dr.GetInt32(10);
                    d.DonationDate = dr.GetDateTime(11);                                 
                    d.BloodBankID = dr.GetInt32(12);
                    d.HBcount = dr.GetInt32(13);
                }
                dr.Close();
                con.Close();
            }
            catch(BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return d;
        }
    }
}
