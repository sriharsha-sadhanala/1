﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.BL;
using System.Data.SqlClient;

namespace BBMS.PL
{
    public partial class BloodProcess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BloodRequestBL rbl=new BloodRequestBL();
            Bloodrequest brq=(Bloodrequest)Session["user"];
            List<Bloodbank> bb = null;
            List<Donor> dlist = null;
            try
            {

                int flag;

                bb = rbl.ProcessReq1(brq, out flag);
                if (flag == 0)
                {
                    dlist = rbl.ProcessReq2(brq,out flag);
                }

                if (flag == 3)
                {
                    lblheading.Text = "Displaying donor list as blood not available in blood bank";
                    grdresult.DataSource = dlist.ToList();
                    grdresult.DataBind();
                }
                else if (flag == 2)
                {
                    lblheading.Text = "Displaying blood bank list having adequate blood amount";
                    grdresult.DataSource = bb.ToList();
                    grdresult.DataBind();
                }
                else if (flag == 1)
                {
                    lblheading.Text = "Details of nearest blood banks having adequate amount of blood";// +x;
                    grdresult.DataSource = bb.ToList();
                    grdresult.DataBind();

                   // int y = 0;
                  
                    //grdresult.AutoGenerateColumns = false;
                    
                   // grdresult.Columns[0].n = "ID";
                    
                    //foreach(DataControlField col in grdresult.Columns)
                    //{
                    //    if(col.HeaderText=="BloodBankId" || col.HeaderText=="BloodBankPwd")
                    //    {
                    //        lblheading.Text = "565615";                            
                    //        col.Visible = false;
                    //    }
                    //}
                   
                    //grdresult.Columns[2].Visible=true;

                    //int x = grdresult.Columns.Count;
                   
                }
                else
                {
                    lblheading.Text = "Failed to display anything. I am such a disappointment. Sorry for letting you down."+flag;
                }
            }

            catch (BloodExceptions b)
            {
              
                lblheading.Text=b.Message;
            }
            catch (SqlException s)
            {

                lblheading.Text = s.Message;
            }
            catch (Exception ex)
            {

                lblheading.Text = ex.Message;
            }
        }
    }
}