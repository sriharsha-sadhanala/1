﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.Exceptions;
using BBMS.Entity;

namespace BBMS.DAL
{
    public class CampDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public bool AddCampDetails(BloodCamp camp)
        {
            bool campadded = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_camp";
                cmd.Parameters.AddWithValue("@bid", camp.BloodBankId);
                cmd.Parameters.AddWithValue("@cid", camp.CampID);
                cmd.Parameters.AddWithValue("@cname", camp.Name);
                cmd.Parameters.AddWithValue("@cadd", camp.Address);
                cmd.Parameters.AddWithValue("@startdate", camp.StartDate);
                cmd.Parameters.AddWithValue("@enddate", camp.EndDate);
                cmd.Connection = con;
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    campadded = true;
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return campadded;
        }

        public BloodCamp GetCampDetailsById(BloodCamp bc)
        {
            //BloodCamp campdetails = null;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_campbyid";
                cmd.Parameters.AddWithValue("@cid", bc.CampID);
                cmd.Parameters.AddWithValue("@bid", bc.BloodBankId);
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                //campdetails = new BloodCamp();
                while (dr.Read())
                {
                    //BloodCamp camp = new BloodCamp();
                    bc.CampID = dr.GetInt32(0);
                    bc.Name = dr.GetString(1);
                    bc.Address = dr.GetString(2);
                    bc.StartDate = dr.GetDateTime(3);
                    bc.EndDate = dr.GetDateTime(4);
                }
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return bc;
        }

        public bool UpdateCampDetails(BloodCamp details)
        {
            bool campupdate = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_campmodi";
                cmd.Parameters.AddWithValue("@cid", details.CampID);
                cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                
                cmd.Parameters.AddWithValue("@cname", details.Name);
                cmd.Parameters.AddWithValue("@cadd", details.Address);
                cmd.Parameters.AddWithValue("@startdate", details.StartDate);
                cmd.Parameters.AddWithValue("@enddate", details.EndDate);
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    campupdate = true;
                }
            }
            catch(BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return campupdate;
        }
        public bool DeleteCampDetails(BloodCamp details)
        {
            bool deleted = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_deletecamp";
                cmd.Parameters.AddWithValue("@bid", details.BloodBankId);
                cmd.Parameters.AddWithValue("@cid", details.CampID);
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                {
                    deleted = true;
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
            return deleted;
        }
    }
}
