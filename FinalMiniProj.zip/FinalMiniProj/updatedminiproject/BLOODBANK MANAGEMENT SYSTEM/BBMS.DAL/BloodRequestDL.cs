﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BBMS.Exceptions;
using BBMS.Entity;

namespace BBMS.DAL
{
    public class BloodRequestDL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hospconn"].ConnectionString);
        SqlCommand cmd;
        public bool AddRequest(Bloodrequest bb)
        {
            bool added = false;

            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "udp_requestadd";
                cmd.Parameters.AddWithValue("@hid", bb.HospitalId);
                cmd.Parameters.AddWithValue("@hname", bb.HospitalName);
                cmd.Parameters.AddWithValue("@haddress", bb.HospAddress);
                cmd.Parameters.AddWithValue("@hregion", bb.HospRegion);
                cmd.Parameters.AddWithValue("@hcity", bb.HospCity);
                cmd.Parameters.AddWithValue("@hdate", bb.ReqDate);
                cmd.Parameters.AddWithValue("@hbgroup", bb.BloodGroup);
                cmd.Parameters.AddWithValue("@humpackets", bb.NoOfPackets);
                
                cmd.Connection = con;

                con.Open();
                int result = cmd.ExecuteNonQuery();


                if (result > 0)
                {
                    added = true;
                    con.Close();
                }
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            return added;
        }

        public List<Bloodbank> ProcessReq1(Bloodrequest brq,out int flag)
        {
            List<Bloodbank> bblist = new List<Bloodbank>();
            
            try
            {
              
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "request_view";
                cmd.Parameters.AddWithValue("@id", brq.HospitalId);
                cmd.Parameters.AddWithValue("@group", brq.BloodGroup);
                cmd.Parameters.AddWithValue("@region", brq.HospRegion);
                cmd.Parameters.AddWithValue("@numofbottles", brq.NoOfPackets);
                

                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                
                if(dr.HasRows)
                {
                    
                    while(dr.Read())
                    {
                        Bloodbank bk=new Bloodbank();
                        bk.BloodBankId=dr.GetInt32(0);
                        bk.BloodBankname = dr.GetString(1);
                        bk.BRegion = dr.GetString(2);
                        bk.Baddress = dr.GetString(3);
                        bk.BloodBankCity = dr.GetString(4);
                        bk.BloodBankMobNo = dr.GetString(5);
                        bblist.Add(bk);
                       
                    }
                    flag = 1;
                    dr.Close();
                    con.Close();
                }
                else
                {
                    dr.Close();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "request_view1";
                    cmd.Parameters.AddWithValue("@id", brq.HospitalId);
                    cmd.Parameters.AddWithValue("@group", brq.BloodGroup);
                    cmd.Parameters.AddWithValue("@city", brq.HospCity);
                    cmd.Parameters.AddWithValue("@numofbottles", brq.NoOfPackets);


                    cmd.Connection = con;

                    //con.Open();
                    SqlDataReader dr1 = cmd.ExecuteReader();
                    
                    if (dr1.HasRows)
                    {
                        
                        while (dr1.Read())
                        {
                            Bloodbank bk = new Bloodbank();
                            bk.BloodBankId = dr1.GetInt32(0);
                            bk.BloodBankname = dr1.GetString(1);
                            bk.BRegion = dr1.GetString(2);
                            bk.Baddress = dr1.GetString(3);
                            bk.BloodBankCity = dr1.GetString(4);
                            bk.BloodBankMobNo = dr1.GetString(5);
                            bblist.Add(bk);
                        }
                        flag = 2;
                        dr1.Close();
                        con.Close();
                    }
                    else
                    {
                        dr1.Close();
                        flag = 0;
                        con.Close();
                    }
                    dr1.Close();
                    con.Close();
                }
                dr.Close();
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            con.Close();
            return bblist;
        }

        public List<Donor> ProcessReq2(Bloodrequest brq,out int flag)
        {
            //AdminReportDL rdl = new AdminReportDL();
            //flag=3;
            //return rdl.GetDonorDetails();
            List<Donor> dlist = new List<Donor>();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "request_donorview";
                cmd.Parameters.AddWithValue("@id", brq.HospitalId);
                cmd.Parameters.AddWithValue("@group", brq.BloodGroup);
                cmd.Parameters.AddWithValue("@city", brq.HospCity);
                


                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    foreach (DataRow item in dr)
                    {
                        Donor bk = new Donor();
                        bk.DonorID = dr.GetInt32(0);
                        bk.firstname = dr.GetString(1);
                        bk.lastname = dr.GetString(2);
                        bk.Address = dr.GetString(3);
                        bk.City = dr.GetString(4);
                        bk.Mobile = dr.GetString(5);
                        
                        dlist.Add(bk);
                    }
                    flag = 3;
                    dr.Close();
                    con.Close();
                }
                else
                {
                    flag = 0;
                }
                dr.Close();
                con.Close();
            }
            catch (BloodExceptions b)
            {
                con.Close();
                throw b;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception ex)
            {
                con.Close();
                throw ex;
            }
            
            con.Close();
            return dlist;
        }
        
    }
}
