﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class BloodBankDetails : System.Web.UI.Page
    {
        BBDetailBL bbl = new BBDetailBL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnmodify_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtbname.Text == string.Empty || txtaddr.Text == string.Empty || txtcity.Text == string.Empty || txtregion.Text == string.Empty || txtcontact.Text == string.Empty)
                {
                    lblmsg.Text = "Values cannot be null";
                }
                else
                {
                    Bloodbank bb = new Bloodbank();

                    bb.BloodBankId = (int)Session["user"];
                    bb.BloodBankname = txtbname.Text;
                    bb.Baddress = txtaddr.Text;
                    bb.BRegion = txtregion.Text;
                    bb.BloodBankCity = txtcity.Text;
                    bb.BloodBankMobNo = txtcontact.Text;

                    if (bbl.UpdateBankDetails(bb))
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record modified successfully')", true);
                        ClearControl_Click(sender, e);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record is not modified.')", true);
                        ClearControl_Click(sender, e);
                    }
                }
            }
            catch(BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }

        protected void txtview_Click(object sender, EventArgs e)
        {
            try
            {
                    Bloodbank bb = new Bloodbank();
                    bb.BloodBankId = (int)Session["user"];
                    bb = bbl.GetBankDetailsById(bb);
                    if (bb.BloodBankname != null)
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record Found')", true);
                        txtbname.Text = bb.BloodBankname;
                        txtaddr.Text = bb.Baddress;
                        txtregion.Text = bb.BRegion;
                        txtcity.Text = bb.BloodBankCity;
                        txtcontact.Text = bb.BloodBankMobNo;
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Record not found')", true);
                        ClearControl_Click(sender, e);
                    }
            }
            catch (BloodExceptions b)
            {
                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message;
            }
            catch (Exception v)
            {
                lblmsg.Text = v.Message;
            }            
        }
        protected void ClearControl_Click(object sender, EventArgs e)
        {
            txtbname.Text = "";
            txtaddr.Text = "";
            txtcity.Text = "";
            txtregion.Text = "";
            txtcontact.Text = "";
        }

    }
}