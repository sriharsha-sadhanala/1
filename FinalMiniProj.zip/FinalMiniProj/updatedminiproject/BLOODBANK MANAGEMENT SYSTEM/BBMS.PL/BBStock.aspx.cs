﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.BL;

namespace BBMS.PL
{
    public partial class BBStock : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        StockBL Sbl = new StockBL();
        
        protected void btnupd_Click(object sender, EventArgs e)
        {
            try
            { 
            if(txthname.Text==string.Empty||txtdate.Text==string.Empty||txtStock.Text==string.Empty)
            {
                lblmsg.Text = "Values cannot be null";
            }
            else
            {
                int bbid = (int)Session["user"];
                int units = Convert.ToInt32(txtStock.Text);
                string grp = dpgrp.SelectedItem.ToString();
                string hname = txthname.Text;
                DateTime dt = Convert.ToDateTime(txtdate.Text);
               
                    if (Sbl.UpdateInventory(bbid, units, grp) == true )
                    {
                        if (Sbl.StockTransfer(bbid, units, hname, grp, dt) == true)
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Inventory updated successfully')", true);
                            txthname.Text = "";
                            txtStock.Text = "";
                            txtdate.Text = "";
                            lblmsg.Text = "";
                        }
                    }                       
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Inventory is not updated')", true);
                        lblmsg.Text = "";
                    }                       
                }
            }
            catch (BloodExceptions b)
            {
                
                lblmsg.Text=b.Message;
            }
            catch (SqlException s)
            {

                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {

                lblmsg.Text = ex.Message;  
            }
        }

        protected void btnexpired_Click(object sender, EventArgs e)
        {
            try
            {
                if (Sbl.DeleteExp())
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Deleted Expired blood successfully')", true);
                    lblmsg.Text = "";
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Failed to delete expired blood')", true);
                    lblmsg.Text = "";
                }
            }
            catch (BloodExceptions b)
            {

                lblmsg.Text = b.Message;
            }
            catch (SqlException s)
            {

                lblmsg.Text = s.Message;
            }
            catch (Exception ex)
            {

                lblmsg.Text = ex.Message;
            }
        }
    }
}