﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BBMS.BL;
using BBMS.Entity;
using BBMS.Exceptions;


namespace BBMS.PL
{
    public partial class BBReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            BBReportBL bbl = new BBReportBL();
            int id = (int)Session["user"];
            if (DropDownList1.SelectedItem.Value == "Donor")
            {
                lblheading.Text = "Donor Details";
                GridView1.DataSource = bbl.GetDonorDetails(id);
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedItem.Value == "Camp")
            {
                lblheading.Text = "Camp Details";
                GridView1.DataSource = bbl.GetCampDetails(id);
                GridView1.DataBind();
            }
            else if (DropDownList1.SelectedItem.Value == "Inventory")
            {
                lblheading.Text = "Inventory Details";
                GridView1.DataSource = bbl.GetInventoryDetails(id);
                GridView1.DataBind();
            }
            else
            {
                lblheading.Text = "Select any option";
            }
        }
    }
}