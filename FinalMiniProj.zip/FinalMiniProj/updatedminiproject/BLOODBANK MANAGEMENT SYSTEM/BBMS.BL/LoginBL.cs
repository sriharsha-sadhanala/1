﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using BBMS.Entity;
using BBMS.Exceptions;
using BBMS.DAL;

namespace BBMS.BL
{
    public class LoginBL
    {
        LoginDL bbda = new LoginDL();

        public bool AdminCheck(AdminLogin admin)
        {
            try
            {
                return bbda.AdminCheck(admin);
            }
            catch(BloodExceptions b)
            {
                throw b;
            }
            catch(SqlException s)
            {
                throw s;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public int ValidateBankLogin(Bloodbank bb)
        {
            try
            {
                return bbda.ValidateBankLogin(bb);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
