﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBMS.Exceptions;
using BBMS.Entity;
using BBMS.DAL;
using System.Data.SqlClient;


namespace BBMS.BL
{
    public class BloodRequestBL
    {
        BloodRequestDL rdl = new BloodRequestDL();
        public bool validrequest(Bloodrequest bb)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();

            if (bb.HospitalId<1000||bb.HospitalId>9999)
            {
                valid = false;
                sb.Append("Enter valid ID");
            }
            if(bb.NoOfPackets<=0||bb.NoOfPackets>8)
            {
                valid = false;
                sb.Append("Please enter valid number of packets");
            }
            if(bb.ReqDate.CompareTo(DateTime.Now)<0)
            {
                valid = false;
                sb.Append("Enter valid date");
            }
            if (valid == false)
            {
                throw new BloodExceptions(sb.ToString());
            }
            return valid;
        }
        public bool AddRequest(Bloodrequest bb)
        {
            bool added = false;
            try
            {
                if (validrequest(bb))
                {
                    added = rdl.AddRequest(bb);
                }

            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return added;
        }

        public List<Bloodbank> ProcessReq1(Bloodrequest brq,out int flag)
        {
            try
            {
                return rdl.ProcessReq1(brq, out flag);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Donor> ProcessReq2(Bloodrequest brq,out int flag)
        {
            try
            {
                return rdl.ProcessReq2(brq,out flag);
            }
            catch (BloodExceptions b)
            {
                throw b;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
